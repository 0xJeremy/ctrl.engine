from face_detection import face_detection
face_detection = face_detection

from image_classification import image_classification
image_classification = image_classification

from object_detection import object_detection
object_detection = object_detection

from post_detection import post_detection
post_detection = post_detection

from image_segmentation import image_segmentation
image_segmentation = image_segmentation
